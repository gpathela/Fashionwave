﻿<?php include ('header.php'); ?>
    <!-- main content -->
    <div id="homepage">
      <!-- services area -->
      <section id="services" class="clear">
      <br>
        <article>
        <h6>About Us</h6>
              
          <p>All about that new? Look no further. Fashionwave is your one-stop shop for the freshest styles you need at seriously affordable prices. We provide you with everything you need to own your #OOTD, with our offering of trend lead women's clothing, inspired from the catwalk and the coolest celeb muses and models of the moment. We've got hundreds of new product dropping on the regular, making all "nothing to wear dilemmas" gone for good. At PrettyLittleThing Australia, when it comes to meeting your fast fashion needs, we've got you covered.</p>
          
        </article>
        
      </section>
      
      <section id="latest">
      <h3>Gallery</h3>
      <br\>
        <article>
        <h6>Recent participation in apparal fair</h6>
          <figure>
            <ul class="clear">
              <li class="one_third"><img src="images/gallery/1.jpg" width="290" height="180" alt=""></li>
              <li class="one_third"><img src="images/gallery/2.jpg" width="290" height="180" alt=""></li>
              <li class="one_third lastbox"><img src="images/gallery/3.jpg" width="290" height="180" alt=""></li>
            </ul>
            
          </figure>
        </article>
      </section>
      <!-- / latest work -->

      <section id="latest">
      <h3>Connect with us</h3>
      <br\>
        <article>
          <figure>
            <ul class="clear">
              <li class="one_third"><a href="#"><img src="images/connect/1.jpg" width="290" height="180" alt=""></a></li>
              <li class="one_third"><a href="#"><img src="images/connect/3.jpg" width="290" height="180" alt=""></a></li>
              <li class="one_third lastbox"><a href="#"><img src="images/connect/4.png" width="290" height="180" alt=""></a></li>
            </ul>
            
          </figure>
        </article>
      </section>
      <!-- / latest work -->
    
  </div>
</div>

<?php include ('footer.php'); ?>

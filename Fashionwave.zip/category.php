﻿<?php include ('header.php'); ?>
   
    <div id="homepage">
      <!-- services area -->
      <section id="services" class="clear">
      <br>
        <article class="two_quarter">
        <ul>
        <li class="two_third"><a href="list.php?cat=men"><img src="images/mens.jpg" width="800" height="250" alt=""></li>
        <li class="two_third"><a href="list.php?cat=women"><img src="images/womens.jpg" width="800" height="250" alt=""></li>
        </ul>   
          
        </article>
        <article class="two_quarter">
          
        </article>
        </section></div>

    
<?php include ('footer.php'); ?>

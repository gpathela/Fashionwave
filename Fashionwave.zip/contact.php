﻿<?php include ('header.php'); ?>
    <!-- main content -->
    <div id="homepage">
      <!-- services area -->
      <section id="services" class="clear">
      <br>
        <article>
        <h6>Contact Us</h6>
              
          <p>17, Snowsill Circuit</p>
          <p>Point Cook</p>
          <p>VIC 3030</p>
          <p>0424895558</p>
          <p>gpathela@gmail.com</p>
          
        </article>
        
      </section>
      
      <section id="latest">
      <h3>Find us</h3>
      <br\>
        <article>
          <figure>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3148.5603303468106!2d144.71561861495925!3d-37.89396367973785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad688a1b640028d%3A0x3f0a93b11369dd63!2s17+Snowsill+Circuit%2C+Point+Cook+VIC+3030!5e0!3m2!1sen!2sau!4v1496707646470" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            
          </figure>
        </article>
      </section>
      <!-- / latest work -->
    
  </div>
</div>

<?php include ('footer.php'); ?>
